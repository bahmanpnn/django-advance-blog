from datetime import datetime
from django.test import TestCase,Client
from django.urls import reverse,resolve
from django.contrib.auth import get_user_model 
from accounts.models import User,Profile
from ..views import SimpleIndexView
from ..models import Post,Category

User2=get_user_model()

# class TestBlogView(TestCase):
    
#     def setUp(self):
#         self.client=Client()

#     # def test_blog_index_url_response_200(self):
#     #     url=reverse('blog:fbv-index')
#     #     response=self.client.get(url)

#     #     self.assertEquals(response.status_code,200)

#     def test_blog_cbv_index_url_response_200(self):
#         url=reverse('blog:simple-cbv-index')
#         response=self.client.get(url)

#         self.assertEquals(response.status_code,200)
#         self.assertEquals(resolve(url).func.view_class,SimpleIndexView)
#         self.assertTrue(str(response.content).find("index"))
#         self.assertTemplateUsed(response,template_name="index.html")


class TestBlogView(TestCase):
    
    def setUp(self):
        """
            in this method we setup client,user,profile and post to use in test methods
        """

        self.client=Client()

        self.user=User.objects.create_user(email="bahmanpn@gmail.com",password='Zx!@1234')
        # user=User.objects.create(email="bahmanpn@gmail.com",password='Zx!@1234')

        self.profile=Profile.objects.create(
            user=self.user,
            first_name='test_first_name',
            last_name='test_last_name',
            description='test desc'
        )

        category_obj=Category.objects.create(name='cat_one')

        self.post=Post.objects.create(
            auhtor=self.profile,
            title="test title",
            content="content",
            status=True,
            published_date=datetime.now(),
            category=category_obj
        )

    def test_blog_cbv_index_url_response_200(self):
        url=reverse('blog:simple-cbv-index')
        response=self.client.get(url)

        self.assertEquals(response.status_code,200)
        self.assertEquals(resolve(url).func.view_class,SimpleIndexView)
        self.assertTrue(str(response.content).find("index"))
        self.assertTemplateUsed(response,template_name="index.html")
    
    def test_blog_post_detail_logged_in_response(self):

        self.client.force_login(self.user)

        url=reverse('blog:post-detail',kwargs={'pk':self.post.id})
        response=self.client.get(url)
        self.assertEquals(response.status_code,200)
    
    def test_blog_post_detail_anonymouse_response(self):
        url=reverse('blog:post-detail',kwargs={'pk':self.post.id})
        response=self.client.get(url)
        self.assertEquals(response.status_code,302)
